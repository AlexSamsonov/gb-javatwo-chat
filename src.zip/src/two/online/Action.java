package two.online;

public interface Action {
    void blink();
}
