package two.online;

public interface MouseListener {
    void mouseUp();
}
