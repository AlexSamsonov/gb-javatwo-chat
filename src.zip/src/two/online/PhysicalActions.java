package two.online;

public interface PhysicalActions extends Action {
    void walk();
    void waveHands();
    void jump(int height);
}
