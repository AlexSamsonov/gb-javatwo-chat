package two.online;

public interface VerbalAction {
    void speak();
    void read();
    void write(String msg);
    void blink();
}
